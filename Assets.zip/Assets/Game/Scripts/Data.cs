using UnityEngine;

namespace DATA
{
	public enum UnitRace
	{
		Offmoths,
		Human_Expeditors,
		Sentient_Automatons,
		Extraterrestrials,
		Planet_Cultists,
		None,
	}
}
Thankyou very much for downloading "8 Bit Retro Rampage: Free Edition".

Within this pack, you will find 150 ready-to-use wav files taken from the full collection, which contains over 1000.

I hope the filenames are fairly self-explanatory - if the sound is intended to be used as a loop, then the filename will include "lp". You may also notice that a lot of the filenames contain "rnd". These sounds are part of a random-pick selection. When dealing with sound effects that are likely to be used a lot (e.g. weapons and explosions in a shooter-style game), then having slight variation within a particular sound group can be very useful. However, the free version of this sound pack does not contain variations.

The sounds themselves are very small in filesize, so should be usable in their original, uncompressed form. Please be aware that some of the sounds have very small looping sections which may not respond well to lossy audio codecs. For these sounds, I suggest leaving the format as original uncompressed PCM. The file sizes should still remain small, given the precision of the editing.

Although I offer these sounds for free, if you do use the sounds in a finished product, I would be grateful if you gave credit to redbuttonaudio.co.uk



Thanks once again




For more information, feel free to mail info@redbuttonaudio.co.uk